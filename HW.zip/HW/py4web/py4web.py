#!/usr/bin/env python3

from py4web.core import cli

cli()

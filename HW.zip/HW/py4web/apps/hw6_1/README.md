# lecture_edit_in_place

Lecture about editing in-place a textarea.  
There are two interesting branches:

* _master_ or _buttons_ : A text area using buttons. 
* _no_buttons_ : A text area not using buttons. 


"""
This file defines actions, i.e. functions the URLs are mapped into
The @action(path) decorator exposed the function at URL:

    http://127.0.0.1:8000/{app_name}/{path}

If app_name == '_default' then simply

    http://127.0.0.1:8000/{path}

If path == 'index' it can be omitted:

    http://127.0.0.1:8000/

The path follows the bottlepy syntax.

@action.uses('generic.html')  indicates that the action uses the generic.html template
@action.uses(session)         indicates that the action uses the session
@action.uses(db)              indicates that the action uses the db
@action.uses(T)               indicates that the action uses the i18n & pluralization
@action.uses(auth.user)       indicates that the action requires a logged in user
@action.uses(auth)            indicates that the action requires the auth object

session, db, T, auth, and tempates are examples of Fixtures.
Warning: Fixtures MUST be declared with @action.uses({fixtures}) else your app will result in undefined behavior
"""

import uuid

from py4web import action, request, abort, redirect, URL, Field
from py4web.utils.form import Form, FormStyleBulma
from py4web.utils.url_signer import URLSigner

from yatl.helpers import A
from . common import db, session, T, cache, auth, signed_url


url_signer = URLSigner(session)

# The auth.user below forces login.
@action('index')
@action.uses('index.html', auth.user, db)
def index():
    logged_in_user = auth.current_user.get('email')
    rows = db(db.person.user_email == logged_in_user).select()
    #print(rows)
    for contact in rows:
        phoneNumbers = db(db.phone.contact_id == contact.id).select()
        phoneList = []
        for phone in phoneNumbers:
            phoneList.append("{0} ({1})".format(phone.phone_number, phone.kind)) 
        phoneStr = ", ".join(phoneList)

        contact['phone_number'] = phoneStr
        
    return dict(rows=rows, user=auth.user, signed_url = signed_url)

@action('add_contact', method=['GET', 'POST'])
@action.uses('contact_form.html', session, db, auth.user)
def add_contact():
    form = Form(db.person, csrf_session=session, formstyle=FormStyleBulma)
    if form.accepted:
        # We always want POST requests to be redirected as GETs.
        redirect(URL('index'))
    return dict(form=form, user=auth.user)

@action('edit_contact/<contact_id>', method=['GET', 'POST'])
@action.uses('contact_form.html', session, db, auth.user)
def edit_contact(contact_id=None):
    """Note that in the above declaration, the contact_id argument must match
    the <contact_id> argument of the @action."""
    # We read the contact.
    p = db.person[contact_id]
    if p is None:
        # Nothing to edit.  This should happen only if you tamper manually with the URL.
        redirect(URL('index'))
    else:
        if p.user_email == auth.current_user.get('email'):
            form = Form(db.person, record=p, deletable=False, csrf_session=session, formstyle=FormStyleBulma)
            if form.accepted:
            # We always want POST requests to be redirected as GETs.
                redirect(URL('index'))
            else:
                return dict(form=form, user = auth.user)
        else:
            redirect(URL('index'))

@action('delete_contact/<contact_id>', method=['GET'])
@action.uses(session, db, auth.user, signed_url.verify())
def delete_contact(contact_id=None):
    #read the contact
    p = db.person[contact_id]
    if p is None:
        redirect(URL('index'))
    else: 
        # delete.
        #print("here")
        if p.user_email == auth.current_user.get('email'):
            db(db.person.id == contact_id).delete() 
        redirect(URL('index'))


@action('phone_index/<contact_id>', method='GET')
@action.uses('edit_phone.html', session, db, auth.user)
def edit_phone(contact_id=None):
    current_user_email = auth.current_user.get("email")
    contact = db.person[contact_id]

    if contact.user_email != current_user_email:
        redirect(URL('index'))

    first_name = contact.get("first_name")

    phones = db(db.phone.contact_id == contact_id).select()

    return dict(contact_id=contact_id, name =first_name, phoneNumbers = phones, signed_url = signed_url, user=auth.user)

@action('edit_phone/<contact_id>/<phoneID>', method=['GET', 'POST'])
@action.uses('add_phone.html', session, db, auth.user)
def edit_phone_number(contact_id=None, phoneID = None):
    current_user_email = auth.current_user.get("email")
    contact = db.person[contact_id]

    phone_number = db.phone[phoneID]

    if contact is None or contact.user_email != current_user_email or phone_number is None:
        redirect(URL('index'))

    c_id = contact.id

    form = Form([Field('phone_number'), Field('kind')], record=phone_number, csrf_session = session, formstyle=FormStyleBulma, deletable=False)

    if form.accepted:
        db(db.phone.id == phoneID).update(phone_number=form.vars.get('phone_number'), kind=form.vars.get('kind'), contact_id=c_id)
        redirect(URL('phone_index', contact_id))
    return dict(form = form, name = contact.first_name, user=auth.user)
     


@action('add_phone/<contact_id>', method=['GET', 'POST'])
@action.uses('add_phone.html', session, db, auth.user)
def add_phone(contact_id = None):
    current_user_email = auth.current_user.get("email")
    contact = db.person[contact_id]

    if contact is None or contact.user_email != current_user_email:
        redirect(URL('index'))

    c_id = contact.id

    form = Form([Field('phone_number'), Field('kind')], csrf_session = session, formstyle=FormStyleBulma)

    if form.accepted:
        db.phone.insert(phone_number=form.vars.get('phone_number'), kind=form.vars.get('kind'), contact_id=c_id)

        redirect(URL('phone_index', contact_id))
    return dict(form = form, name = contact.first_name, user=auth.user)

@action('delete_phone/<contact_id>/<phoneID>', method=['GET', 'POST'])
@action.uses(db, session, signed_url.verify())
def delete_phone(contact_id=None, phoneID=None):
    current_user_email = auth.current_user.get("email")
    contact = db.person[contact_id]

    phone_number = db.phone[phoneID]

    if contact is None or contact.user_email != current_user_email or phone_number is None:
        redirect(URL('index'))

    db(db.phone.id == phoneID).delete()
    redirect(URL('phone_index', contact_id))
